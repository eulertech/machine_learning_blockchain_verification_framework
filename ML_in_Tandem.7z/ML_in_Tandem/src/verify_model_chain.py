import logging
import os

def verify_chain():
    status = 0
    return status
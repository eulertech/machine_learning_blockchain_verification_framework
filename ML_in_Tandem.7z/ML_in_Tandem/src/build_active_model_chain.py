import logging
import os

def build_chain():

    status = 0
    return status
'''
framework:
1. function build_model_chain (f0,f1,f2,f3,f4)
2. get_parent() # method
3. get_transaction(n) # method
4. get_total_transaction() # method
5. print_chain()
6. get_first_chain()
7. get_last_chain()
8. compare_two_chain(chain obj)

Author: Liang Kuang
Date: 2019-01-11
'''
import os
import hashlib
import datetime

class block():
    def __init__(self, index, timestamp, data, previous_hash):
        # initialize with a empty or loaded chain object
        # chain is a blockchain class object
        self.author = 'liang kuang'
        self.timestamp = timestamp
        self.data = data
        self.previous_hash = previous_hash  # TODO: should I used name previous_block instead?
        self.hash = self.hash_block()

    def hash_block(self):
        md5 = hashlib.md5()
        md5.update(str(self.index).encode() +
                   str(self.timestamp).encode() +
                   str(self.data).encode() +
                   str(self.previous_hash).encode()
                   )
        return md5.hexdigest()

    def get_block_length(self):
        cnt = 0
        tempBlock = self.hash
        while tempBlock is not None:
            tempBlock = tempBlock.previous_hash
            cnt = cnt + 1
        return cnt

    def get_first_block(self):
        parent = self.hash
        while self.previous_hash is not None:
           parent = parent.previous_block
        return parent

    def get_last_block(self):
        return self.hash

    def get_nth_block(self,n=1):
        # by default will get the first
        cnt = self.get_block_length()
        if n > cnt:
            return None
        tempBlock = self.hash
        while tempBlock is not None:
            tempBlock = tempBlock.previous_hash
            cnt = cnt - 1
            return tempBlock

    def get_previous_block(self):
        return self.previous_hash

    def print(self):
        print("print block from end to beginning.")
        block = self.hash
        print("The last block is: %s\n"%block)
        while block is not None:
            block = block.previous_hash
            print("The previous block is: %s\n"%block)

    def save(self, filename):
        with open(filename, 'w') as f:
            f.write(self.hash)

    def load(self, filename):
        if not os.path.isfile(filename):
            raise IOError(FileNotFoundError)
        with open(filename, 'r') as f:
            block = f.read()
        return block

    if __name__ == "__main__":
        from blockchain import create_genesis_block
        from blockchain import create_next_block

        blockchain = [create_genesis_block(0)]
        previous_block = blockchain[0]

        num_blocks = 10
        for i in range(0, num_blocks):
            block2add = create_next_block(previous_block)
            blockchain.append(block2add)
            previous_block = block2add

            print("Block %d has been added to the blockchain \n", block2add.index)
            print("Hash: %s\n", block2add.hash)

def create_genesis_block(self, data="Genesis block", previous_hash="0"):
    from blockchain import block
    import datetime
    return block(0, datetime.datetime.now(), data, previous_hash)

def create_next_block(self, last_block):
    from blockchain import block
    this_index = last_block.index + 1
    this_timestamp = datetime.datetime.now()
    this_data = "Creating block number + " + str(this_index)
    this_hash = last_block.hash
    return block(this_index, this_timestamp, this_data, this_hash)

def build_model_chain(list_of_files):
    '''
    :param list_of_files: list of files from genesis to the end block
    :return: a blockchain object
    '''
    from blockchain import block
    from blockchain import create_genesis_block
    if len(list_of_files) == 0:
        raise ValueError("The list of files must not be empty")
    else:
        model_chain = block()
        for i in range(len(list_of_files)):
            if i == 0:
                index = i
                timestamp = datetime.datetime.now()
                data = open(list_of_files[i]).read() # TODO: need to replace with read by bytes for memory
                model_chain.create_genesis_block(0, timestamp, data)
            else:
                index = i
                timestamp = datetime.datetime.now()
                data = open(list_of_files[i]).read() # TODO: need to replace with read by bytes for memory
                model_chain.create_genesis_block(0, timestamp, data)
    return model_chain

    #def __init__(self, index, timestamp, data, previous_hash):

def compare_model_chains(chain1, chain2):
    pass

def compare_nth_block(chain1, chain2, n):
    # compare the nth block starting from parent
    pass




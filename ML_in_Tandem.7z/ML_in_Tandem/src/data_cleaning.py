import pandas as pd
import numpy as np
import os
import logging
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from config import CONFIG

logfile = CONFIG.get('Paths','log_file')
logger = logging.getLogger(__name__)
logging.basicConfig(
#    filename=logfile,  # this will put all logging to main log file
    filemode='w',
    format='%(asctime)s %(message)s',
    datefmt='%m%d%Y %I:%M:%S',
    level=logging.DEBUG
)
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
logger.addHandler(ch)

logger.info("data cleaning module.")

m = CONFIG.get('data_generation','num_samples')
n = CONFIG.get('data_generation', 'num_features')
raw_data_path = CONFIG.get('Paths','raw_data_path') + '/raw_data.npy'
data_raw_loaded = np.load(raw_data_path)
X = data_raw_loaded[:,0:int(n)]
y = data_raw_loaded[:,-1].reshape((int(m),1))
# data cleaning config
dropFeat = CONFIG.getboolean('data_cleaning','drop_feature')
#dropFeat = CONFIG['data_cleaning']['drop_feature']
new_feature_num = CONFIG['data_cleaning']['reduced_col_num']
logger.info(type(dropFeat))
if dropFeat:
    processed_data_path = CONFIG.get('Paths','processed_data_path') + '/processed_data.npy'
    logger.info("Drop features")
    X_dropped = X[:,0:int(new_feature_num)]
    data_processed = np.hstack((X_dropped, y))
    np.save(processed_data_path, data_processed)

logger.info("Dta cleaning is done.")

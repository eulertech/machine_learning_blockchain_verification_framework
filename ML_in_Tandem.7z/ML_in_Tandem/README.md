# ML_in_tandem
ML framework for tandem model and verification process
